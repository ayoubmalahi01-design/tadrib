# THE TRAINERS (تدرّب) — Implementation Changelog

## Round 13 — language parity guard (F6 follow-up)

- New `tests/i18n-parity.test.ts` (6 tests). `Key` is derived from the Arabic dictionary, so a label missing from French or English could still compile and then render as a raw key or a blank control. The suite now pins the direction that matters: every Arabic key must exist as a non-empty string in ar, fr **and** en; no value may be a placeholder (`todo`, `tbd`, `undefined`, the key name itself); `makeT(lang)` must resolve every key in every language without echoing the key back; only `ar` is RTL; and the eight labels added in round 12 must exist in all three languages with Arabic and French wording that differs from English.
- Result: the dictionaries already satisfied all of it — no translation had to be added or repaired. The guard exists so future edits cannot silently break it.
- Verified: `npm test` **53/53**, `npm run build` OK, `npm run verify` 28 checks.

## Round 12 — report drafts (D8) and notification delivery (D19)

Daily reports were previously all-or-nothing: closing the modal, reloading the tab or losing signal discarded every typed observation, and the only write path was `status:'submitted'`. The audit asked for create → save draft → edit draft → submit.

- New `src/lib/report-draft.ts`: a versioned, per-user, expiring local snapshot (`tt.report-draft.<userId>`, 7-day TTL). `saveReportDraft` / `loadReportDraft` / `clearReportDraft` / `hasDraftContent` never throw when storage is missing or full, sanitise counts to non-negative integers, reject corrupt JSON, foreign versions and future timestamps, and key everything by user id so a shared tablet cannot leak one coach's draft to another.
- `src/App.tsx` (Reports): the form autosaves on every change; reopening it restores the snapshot and says so (`draftRestored`). A new **Save draft** button writes a real `daily_reports` row with `status:'draft', is_finalized:false` and remembers its id, so repeated saves update that row instead of duplicating it. Draft rows now show a **Continue draft** action for the owning coach, which reloads counts and notes for editing. Submitting converts the same row to `submitted`/`is_finalized:true` and clears the local snapshot. Authorisation is unchanged and server-side: `reports_insert_own` for the insert, `reports_update_own_draft` for the draft update, and `lock_final_report` still rejects any edit once finalized.
- New `src/lib/push-notify.ts`: `pushNotification` shows an OS notification only when the API exists, permission is `granted`, the tab is hidden and the title is non-empty; `pushBlockedReason` reports why not; `requestPushPermission` wraps the browser prompt. All rules are injectable, so they are unit tested without a browser.
- `src/App.tsx` (Notifications): the Realtime `INSERT` handler now delivers a system notification for the new row, and an **Enable notifications** button appears while permission is still `default`, reporting the outcome as a toast.
- `src/App.tsx` (Modal): the close button's `aria-label`/`title` was the hard-coded English `"Close"`; it now takes a `closeLabel` prop (Reports passes `t('close')`).
- `src/lib/i18n.ts`: `saveDraft`, `draftSaved`, `draftRestored`, `continueDraft`, `enableNotifications`, `notificationsOn`, `notificationsBlocked`, `close` added in ar/fr/en.
- `supabase/migrations/0002_report_draft_submit_notify.sql` (additive, **not executed**): the existing notification trigger fires `AFTER INSERT ... WHEN new.is_finalized`, so submitting a *saved draft* — an UPDATE — notified nobody. The migration adds one trigger on the `false → true` transition of `is_finalized`, reusing `notify_submitted_report()`; it creates no table, column or policy and is re-runnable.
- `tests/report-draft.test.ts` (10) and `tests/push-notify.test.ts` (7): per-user scoping, TTL expiry, corrupt/foreign snapshots, count sanitising, unavailable storage, delivery gating and the empty-title case.
- Verified: `npm test` **47/47**, `npm run build` OK (entry 88.8 kB), `npm run verify` 28 checks.
- Not verified: no live database, so draft insert/update against real RLS and the system notification popup were not exercised end to end; the logic is unit-tested and the policies were read from the schema.

## Round 11 — bundle splitting (F12) and no third-party fonts (F15)

- `vite.config.ts`: added `manualChunks` splitting `react-vendor` (react, react-dom, react-router-dom), `supabase` (@supabase/supabase-js) and `icons` (lucide-react) out of the entry bundle. Same build before/after: **477 kB (135 kB gzip) in one file** became `index 83.9 kB (23.6 gzip)` + `react-vendor 164.5 kB (53.8)` + `supabase 214.4 kB (55.5)` + `icons 13.9 kB (3.4)`. Vendor code is now cached across releases instead of re-downloaded on every deploy.
- `src/styles.css`: removed the `@import url('https://fonts.googleapis.com/...')` for IBM Plex Sans Arabic and Inter and installed a native Arabic-capable stack (`system-ui, -apple-system, Segoe UI, Roboto, Noto Sans Arabic, Noto Kufi Arabic, IBM Plex Sans Arabic, Inter, Tahoma, Arial`). Arabic, French and English keep full glyph coverage, first paint no longer waits on a third-party origin, and offline rendering works.
- `public/_headers`: CSP tightened — `style-src 'self' 'unsafe-inline'` and `font-src 'self' data:` no longer permit `fonts.googleapis.com` / `fonts.gstatic.com`.
- Honest limitation: the audit item asked for **self-hosted font files**. Downloading the woff2 binaries was blocked by the sandbox's network guard, so they are not vendored. The third-party dependency itself is gone, which removed the real risk (privacy leak, extra CSP origin, offline fallback). If the owner wants IBM Plex/Inter exactly, drop the woff2 files into `public/fonts` and reference them with `@font-face`.
- Verified: `npm test` **31/31**, `npm run build` OK (four chunks listed above), `npm run verify` 28 checks.

## Round 10 — non-blocking notifications (F13) and dead imports (F18)

- New `src/lib/toast.ts`: `notify(message)` plus `setToastListener(fn)`. The shell registers a listener; every failure and confirmation now renders as a dismissible, `aria-live="polite"` banner instead of a blocking `window.alert`. When no listener is mounted the message is logged, so the channel can never throw.
- `src/App.tsx`: all **50** `alert(...)` call sites were converted to `notify(...)` — `grep -c` earlier reported 28 because it counts lines, not occurrences. The banner auto-dismisses after six seconds and can be tapped to dismiss immediately. Errors no longer interrupt a coach mid-attendance entry on a phone.
- `src/App.tsx` imports: removed three genuinely dead icon imports (`BookOpen`, `FileText`, `Clock3`). Five other candidates (`Home`, `CalendarDays`, `History`, `HeartPulse`, `SettingsIcon`) looked unused in JSX but are referenced by the `navItems` array, so they were kept — deleting them would have broken navigation.
- `src/styles.css`: `.toast` — fixed above the safe area on phones, anchored bottom-end on desktop, high contrast.
- `tests/toast.test.ts`: four tests covering delivery, ignoring empty/null messages, unbinding, and a stale unbind not detaching a newer listener.
- Verified: `npm test` **31/31**, `npm run build` OK, `npm run verify` 28 checks.
- Not verified: the banner was not observed in a browser session against live data; behaviour is covered by the unit tests plus the typecheck.


## Round 9 — locale-aware dates (F19)

- `src/lib/i18n.ts`: added `setDateLocale(lang)`, `formatDateTime(value)` and `formatTime(value)` built on `Intl.DateTimeFormat` with the active locale (`ar` / `fr` / `en`), falling back to the raw string when a value cannot be parsed.
- `src/App.tsx`: report, attendance, message and notification timestamps now render through these helpers instead of `new Date(...).toLocaleString()` with no locale argument, which previously produced English, month-first output inside the Arabic RTL interface.
- `tests/i18n.test.ts`: regression tests pin the three locales and the unparsable-input fallback.
- Verified: `npm test` 27/27 at that point, `npm run build` OK, `npm run verify` 28 checks.

## Round 8 — group member management (F8/D15)

- `src/App.tsx` (Messages): added `loadConvMembers()`, `addMember()` and `removeMember()` over `conversation_members`. Group conversations now expose a "group members" button in the chat header that opens a modal listing current members, letting the creator or an institution administrator remove a member (the creator is never offered for removal) and add any active institution member who is not already in the conversation.
- Authorisation is enforced by the existing RLS policies `conversation_members_creator_add` and `conversation_members_remove`, so the UI restriction is a convenience layer, not the security boundary.
- `src/lib/i18n.ts`: `groupMembers`, `addMember`, `removeMember`, `membersHelp` in ar/fr/en.
- `src/styles.css`: `.member-list` (scrollable, capped height) and `.members-btn`.
- Verified: `npm test` 24/24, `npm run build` OK, `npm run verify` 28 checks.
- Not verified: add/remove was not executed against a live database; a coach who is not the group creator will be refused by RLS with a surfaced error rather than a silently disabled control.


## Round 7 — messaging: unread badges, read receipts, history paging (F9/D14/D16/D17)

- `src/App.tsx` (Messages): added `loadUnread()` using the existing `unread_counts()` RPC and `openConversation()`, which selects a conversation and calls `mark_conversation_read(p_conversation_id)`. Unread totals now appear as a badge (capped at `99+`) on each conversation row, refresh on load, on conversation open and on every realtime insert.
- Message history: `loadMessages` previously ordered ascending with `limit(200)`, which returned the **oldest** 200 messages and would hide new ones in a long conversation. It now orders descending with `limit(50)` and reverses for display. A `loadOlder()` action pages backwards with `.lt('created_at', oldest)` and prepends, so history is complete instead of silently truncated.
- Fixed an untranslated literal in Notifications: the acknowledge button said `Read` in every language; it now uses `t('markRead')`.
- `src/lib/i18n.ts`: `loadOlder` added in ar/fr/en; `markRead` already existed and was reused.
- `src/styles.css`: `.unread-badge` and `.load-older`.
- Build caught a real defect in my own first attempt — an unmatched parenthesis in the realtime cleanup (`return((()=>…`) — which `tsc` rejected; corrected before this round was accepted.
- Verified: `npm test` 24/24, `npm run build` OK, `npm run verify` 28 checks.
- Not verified: badges and read receipts were not exercised against a live database, so RLS behaviour of `message_reads` and the RPC grants is confirmed by reading the schema only.


## Round 6 — password recovery (F7/S2) and modal accessibility (F14)

- `src/App.tsx` (Login): added `resetPassword()` calling `supabase.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin })`, guarded by the existing `isConfigured` check so an unconfigured build explains itself instead of throwing. A secondary "forgot password" button sits under the sign-in button, is disabled while either request is in flight, and a success panel confirms the link was sent. Empty email produces a specific instruction rather than a silent no-op.
- `src/App.tsx` (Modal): the dialog now exposes `role="dialog"`, `aria-modal="true"` and `aria-label={title}`, takes focus on open, closes on `Escape`, and closes on backdrop click without closing when the click lands inside the panel.
- `src/lib/i18n.ts`: `forgotPassword`, `resetEmailFirst`, `resetSent`, `sendingReset` added in ar/fr/en.
- `src/styles.css`: `.notice-box` success panel and `.modal:focus` outline reset.
- Verified: `npm test` 24/24, `npm run build` OK, `npm run verify` 28 checks.
- Owner action required for the flow to actually deliver mail: add the deployed origin to the Supabase Auth redirect allow-list. Without it Supabase rejects the `redirectTo`. Not verifiable in this environment (no project credentials).
- Known gap: the modal close button's accessible name is the literal `Close` because `Modal` receives no translator; the dialog itself is labelled with its translated title.


## Round 5 — one-tap bulk attendance (D6)

- `src/App.tsx` (Attendance): added `markAllPresent()` and `clearAll()` plus a toolbar with two buttons. A coach can now fill an entire group as present in one tap, or reset the sheet, instead of setting every student individually; both buttons are disabled when no students are loaded, and clearing also drops the per-student reason text so no stale note is saved with a new status.
- `src/lib/i18n.ts`: `markAllPresent` and `clearAll` added in ar/fr/en.
- `src/styles.css`: `.attendance-bulk` wraps to two full-width touch targets (min 40px) on narrow phones.
- Verified: `npm test` 24/24, `npm run build` OK, `npm run verify` 28 checks.
- Not verified: the buttons were not exercised in a browser against a live Supabase session, so the save path is covered by the existing attendance-core unit tests rather than an end-to-end click.


## Round 4 — account gate messaging (audit: wrong message for rejected users)

- Added `src/lib/account-gate.ts`: a pure `accountGate(profile, loadError)` returning `active | pending | rejected | suspended | missing | error`, plus `gateTitleKey`, `gateBodyKey` and `gateAllowsRetry`.
- `src/App.tsx`: the pre-app gate no longer collapses three different situations into "pending approval". A failed profile read (`profiles` query error, e.g. an RLS denial) now shows a retry screen with the real error; an account with no profile row is told it is not linked to an institution yet; rejected and suspended keep their own wording. `loadProfile` now clears the stored error on success and never leaves a stale profile on failure.
- `src/lib/i18n.ts`: added `profileLoadFailedTitle`, `profileLoadFailedMsg`, `profileMissingTitle`, `profileMissingMsg` in ar/fr/en (`retry` already existed).
- Added `tests/account-gate.test.ts` (9 tests): status casing/whitespace, unknown status treated as pending and never active, load error vs missing profile, "rejected is never shown the pending message", retry only for errors, and every gate key present in all three dictionaries.
- Verified: `npm test` 24/24, `npm run build` OK, `npm run verify` 28 checks.


## Round 3 — untranslated strings (F6) and CSP (F10/S1)

- `src/App.tsx`: every remaining hard-coded Arabic UI string was replaced with a `t('key')` lookup — attendance status chips and reason field, the Excel import dialog, all messaging dialogs (invite coach, new conversation, participants), conversation type badges, empty states and button labels (47 literals). Excel header aliases on lines 19 and 22 stay literal on purpose: they match pasted spreadsheet data, not interface text. The language `<option value="ar">العربية</option>` keeps its endonym, which is standard practice.
- `src/lib/i18n.ts`: 40 new keys added to all three dictionaries; ar/fr/en parity is preserved and covered by `tests/i18n.test.ts`.
- `public/_headers`: added `Content-Security-Policy` restricting scripts to self, connections to Supabase REST/Realtime, images and media to Supabase storage plus blob (voice notes), styles to self plus Google Fonts, with `object-src 'none'` and `frame-ancestors 'none'`.
- Verified this round: `npm test` 15/15, `npm run build` OK, `npm run verify` 28 checks.
- Not verified: the CSP only takes effect behind a host that honours `_headers` (Cloudflare Pages / Netlify). `vite preview` ignores it, so no local browser assertion proves it does not break the live app; it should be re-checked on the first authorized deployment.


Branch: `appjet` · All work isolated to this branch. `main` was not touched.

---

## 2026-11-13 — Attendance correctness and verification baseline

### Added

- Pre-save shift guard: when a coach has no open shift, the attendance view now
  asks for confirmation before saving (`startShiftPrompt`, translated into
  Arabic, French and English). This closes the remaining F2 gap where a coach
  without a shift would silently save under the shared `unspecified` session
  key and could merge with another same-day session. `saveAttendance` accepts
  the already-resolved session key so `coach_shifts` is queried once, not twice.
- `src/lib/attendance-core.ts` — pure attendance rules with no Supabase or
  `import.meta.env` dependency: `NO_SESSION`, `isMissingSessionColumn`,
  `friendlyAttendanceError`, `buildAttendanceRows`, plus the `AttendanceInput`,
  `AttendanceRecord`, `AttendanceStatus` and `PgError` types.
- `src/lib/attendance.ts` — persistence layer: `resolveSessionKey`,
  `loadAttendance`, `saveAttendance`. Upserts on
  `(student_id, session_date, session_key)` and falls back to the previous
  two-column shape when the column does not exist yet.
- `supabase/migrations/0001_attendance_session_dimension.sql` — additive,
  idempotent, data-preserving migration adding the session dimension and moving
  the uniqueness rule to `(student_id, session_date, session_key)`.
- `tests/attendance-core.test.ts` — 9 assertions covering the missing-column
  detection, error mapping, duplicate prevention, reason normalisation and the
  six attendance statuses.
- `tests/i18n.test.ts` — 6 assertions enforcing translation key parity, non-empty
  labels and correct RTL across Arabic, French and English.
- `docs/IMPLEMENTATION_REPORT.md`, `docs/FINAL_TEST_REPORT.md`,
  `docs/DATABASE_REQUIREMENTS.md`, `docs/DEPLOYMENT_READINESS.md`,
  `docs/IMPLEMENTATION_CHANGELOG.md`.

### Fixed

- **F2 (High, data correctness).** Attendance could not record a student twice in
  one day. The upsert on `(student_id, session_date)` silently became an `UPDATE`
  of another coach's row and was rejected by RLS. Now the session identity comes
  from the coach's open `coach_shifts` row and the conflict target includes it.
- **F3 (Medium).** Daily report counts were aggregated across the whole day; they
  are now scoped to the reporting coach's own records.
- **F1 (High, CI).** Missing `.gitignore` made `npm run verify` abort before any
  real assertion; it is now present and the full 28-assertion suite runs.
- **F5 (Medium).** Duplicate translation dictionaries consolidated: `src/lib/i18n.ts`
  is the single source, `App.tsx` uses `makeT(lang)`, and key parity is now
  enforced by tests.
- **Environment documentation.** `.env.example` now documents
  `VITE_SUPABASE_ANON_KEY` alongside `VITE_SUPABASE_PUBLISHABLE_KEY`, with an
  explicit warning that service-role keys must never be placed there. This was a
  real `verify` failure.
- **Untranslated labels.** The reports view had hard-coded Arabic strings
  ("الإجراء", "اعتماد التقرير", "تمت المراجعة" and two explanatory notes). They now
  resolve through the dictionary in all three languages.

### Changed

- `src/App.tsx` attendance component now delegates to `loadAttendance` /
  `saveAttendance` / `buildAttendanceRows` instead of building upsert payloads
  inline. Save feedback reports the row count and warns when the session
  dimension is inactive.
- `package.json` — added `"test": "node --import tsx --test tests/*.test.ts"` and
  `tsx` as a dev dependency.

### Verified

- `npm test` — 15/15 pass.
- `npm run build` — type check clean, production bundle built.
- `npm run verify` — 28/28 assertions across 14 required files.
- Dependency scan — 162 packages, 0 high/critical, 2 moderate (`react-router`
  6.30.6, fixed only in 7.18.0, deliberately not force-upgraded).

### Not done in this round

- Migration 0001 not executed (owner action).
- No live Supabase authentication, RLS, storage or Realtime test.
- No device, PWA installation or offline-behaviour test.
- Audit findings beyond F1–F5 were not re-verified; AUDIT_REPORT.md remains the
  checklist for those.

---

## Notes for the next round

Priority order, by risk:

1. Apply migration 0001 in a staging project and confirm the fallback path is no
   longer taken (`migrationRequired` should be `false`).
2. Add an RLS integration test project with seeded users for each role — this is
   the largest remaining confidence gap.
3. Prompt coaches to start a shift before marking attendance, so same-day
   sessions do not silently merge under `'unspecified'`.
4. Plan the `react-router` v7 upgrade with a navigation regression pass.
5. Continue the remaining audit items against AUDIT_REPORT.md.

---

## Round 13 — functional gaps closed

- Removed the bulk/pasted student importer at the owner's request.
- Added the coach private notebook with search, date range, edit, delete and
  per-coach draft recovery (`src/lib/notebook-utils.ts`).
- Announcements: per-user read tracking plus administrator read counts, with a
  graceful fallback when the tracking table is absent; migration 0003 added
  (not executed).
- Messaging: conversation and message search, and a retry bar that keeps the text
  and attachment after a failed send (`src/lib/chat-utils.ts`).
- Reports: coach-name search, status filter and from/to date filter.
- Notifications: open the related screen by notification type, and mark all as read.
- Seven new translation keys in Arabic, French and English.
- Verified with `npm test` (67/67) and `npm run build` (pass). Details in
  `docs/ROUND13_REPORT.md`.
